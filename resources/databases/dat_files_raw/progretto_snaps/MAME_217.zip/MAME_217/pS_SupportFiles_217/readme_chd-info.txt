﻿progetto-SNAPS © 2016/2019 AntoPISA

MAME CHD-Info v0.217
====================
In this package you can find these ini files:
SL folder: All SL CHD dats.
CHD-Info_XXX.txt: With detailed information on all CHD supported by MAME.
CHD_diff_XXX_XXX.dat: With the changes between the last two released versions.
MAME_CHD_XXX.dat: With dat comprising only the CHD.

Credits:
--------
- Thanks to Armax for Data File Creator (for data production).
- Thanks to Guy Peters for the CHD verification tool.


Home-page: http://www.progettosnaps.net/renameset/