﻿MAME MESSINFO.DAT 0.217  December 29, 2019
© AntoPISA               progettoSNAPS.net
------------------------------------------

11.38 29/12/2019: Aligned files to 0.217 version.
11.37 23/12/2019: Added the file 'messinfoREM.dat' to the package with the machines and devices removed from the MESS/MAME.
11.36 15/12/2019: Added 300 device authors.
11.35 01/12/2019: Aligned files to 0.216 version.
11.34 20/11/2919: Published a "git" version, aligned to the MESS of the Nov 18, 2019.
11.33 09/11/2919: Published a "git" version, aligned to the MESS of the Nov 8, 2019.
11.32 07/11/2019: Aligned files to 0.215 version.
11.31 29/09/2019: Aligned files to 0.214 version.
11.30 09/09/2019: Aligned files to 0.213 version.
11.29 11/08/2019: Aligned files to 0.212 version.
11.28 09/07/2019: Aligned files to 0.211 version (version 0.210 was not published due to lack of time, sorry).
11.27 28/04/2019: Aligned files to 0.209 version.
11.26 02/04/2019: Aligned files to 0.208 version.
11.25 03/03/2019: Aligned files to 0.207 version.
11.24 07/02/2019: Aligned files to 0.206 version.
11.23 18/01/2019: Added on the page the link to download the file in "git" format, updated about once a week.
11.22 28/12/2018: Aligned files to 0.205 version.
11.21 25/12/2018: Fixed 1,051 obsolete device descriptions. Added numerous authors of device drivers and information on the devices themselves.
11.20 16/12/2018: Fixed 77 machine manufacturers.
11.19 11/12/2018: Fixed 573 obsolete machine descriptions.
11.18 01/12/2018: Aligned files to 0.204 version.
11.17 15/11/2018: Fixed some errors.
11.16 02/11/2018: Aligned files to 0.203 version.
11.15 01/10/2018: Aligned files to 0.202 version.
11.14 01/09/2018: Aligned files to 0.201 version.
11.13 25/08/2018: 38 wrong entries removed; mostly these are devices renamed in 0.187 version. Added also the authors of 5 drivers.
11.12 30/07/2018: Aligned files to 0.200 version.
11.11 02/07/2018: Aligned files to 0.199 version.
11.10 02/06/2018: Aligned files to 0.198 version.
11.09 29/04/2018: Aligned files to 0.197 version.
11.08 02/04/2018: Aligned files to 0.196 version.
11.07 02/03/2018: Aligned files to 0.195 version.
11.06 04/02/2018: Aligned files to 0.194 version.
11.05 29/12/2017: Aligned files to 0.193 version.
11.04 01/12/2017: Aligned files to 0.192 version.
11.03 30/10/2017: Aligned files to 0.191 version.
11.02 15/10/2017: From today I update the file every 4/5 days; thanks to the xml file provided by Ashura-X here http://ashura.mameworld.info/nightlybuilds/mess_builds.html.
11.01 01/10/2017: Aligned files to 0.190 version.
11.00 23/09/2017: Completed work on formatting correction, deletion of rom data and finding the version of adding all devices. The file is finally complete!
10.38 06/09/2017: Fixed some new "DRIVER STATUS".
10.37 05/09/2017: Aligned files to 0.189 version.
10.36 20/08/2017: Added versions were are added the device (now up to the 0.160 version) and many error fixed.
10.35 15/08/2017: Correction continues in file formatting and even removal of ROMs of each machine (now visible by MAME itself).
10.34 01/08/2017: Aligned files to 0.188 version.
10.33 30/07/2017: Added versions were are added the device (from version 0.148u1 to 0.148u3).
10.32 27/07/2017: Start the correction of formatting and use of the blank lines in the file. This job will continue for the next few months.
10.31 04/07/2017: Aligned files to 0.187 version.
10.30 30/06/2017: Finished the inversion of "whatsnew.txt" comments. Deleted from the package the "changelog.txt" file (which is now only available on the web page).
10.29 08/06/2017: Aligned files to 0.186 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.28 01/05/2017: Aligned files to 0.185 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.27 06/04/2017: Aligned files to 0.184 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.26 15/03/2017: Added versions  were are added the device (from version 0.146u1 to 0.148).
10.25 01/03/2017: Aligned files to 0.183 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.24 15/02/2017: Added versions were are added the device (from version 0.143u3 - the first with these items - to 0.146).
10.23 31/01/2017: Aligned files to 0.182 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.22 15/01/2017: Added all Devices entries (but missing the versions in which they were added).
10.21 04/01/2017: Aligned files to 0.181 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.20 06/12/2016: Aligned files to 0.180 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.19 28/10/2016: Aligned files to 0.179 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.18 03/10/2016: Aligned files to 0.178 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.17 07/09/2016: Aligned files to 0.177 version. Updated: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.16 20/08/2016: Fixed some duplicated entries.
10.15 15/08/2016: Added dmax8000.cpp, fcisio.cpp, sm7238.cpp and tv990.cpp driver entries (I had forgotten).
10.14 06/08/2016: Aligned files to 0.176 version. Updated this files: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.13 09/07/2016: Aligned files to 0.175 version. Updated this files: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.12 02/06/2016: Aligned files to 0.174 version. Updated this files: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.11 31/05/2016: Fixed some errors in 0.173 infos.
10.11 07/05/2016: Aligned files to 0.173 version. Updated this files: 'sourcechanges.txt', 'changelog.txt' and 'alltimesMESS.txt'.
10.10 04/04/2016: Aligned files to 0.172 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until March 30, 2016 (r46892).
10.09 29/02/2016: Aligned files to 0.171 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until February 24, 2016 (r45196).
10.08 31/01/2016: Aligned files to 0.170 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until January 27, 2016 (r44512).
10.07 27/01/2016: JuLePe fixed some type errors in c900, juicebox, krista2, kristall2, lcmate2 and pc9821v13 information.
10.06 10/01/2016: Check (by JuLePe) information relating to "Save State" of all drivers and fixed the wrong ones.
10.05 09/01/2016: Updated information for these systems abc110, bbca, bbcb_de, bbcb_us, bbcbp, bbcbp128 and pro128s by Nigel Barnes and also genesis and h21 from JuLePe.
10.04 04/01/2016: Aligned files to 0.169 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until December 30, 2015 (r43025).
10.02 01/12/2015: Various corrections suggested by JuLePe: deleted the internal references of the sites [##], 'see the more...', 'see below' and 'see pictures'. Correcting the "?" characters which include: Accented vowels (á, é, í, ó, ú, è, ö, ä, ã, å), Slovakian/Serbian characters (Š, ?, ?, ý), Asian characters (tg16 system), apostrophes (wouldn't, computer's,...), another characters (£ € ¥ ½ ¼ ® ™ µ ° ? ß(German ss) ± ² ³ ...). From now on, the file will be available exclusively in UTF-8 format.
10.03 22/12/2015: Updated the SVN until December 22, 2015 (r42904).
10.01 29/11/2015: Aligned files to 0.168 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until November 25, 2015 (r41860).
10.00 02/11/2015: Aligned files to 0.167 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until October 28, 2015 (r41413).
 9.21 31/10/2015: End of phase 9, finding all driver authors!
 9.20 04/10/2015: Aligned files to 0.166 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until September 30, 2015 (r40959).
 9.19 27/09/2015: Added other authors (97% right).
 9.18 29/08/2015: Aligned files to 0.165 version. Fixed some typos error. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until August 26, 2015 (r40488). Added other authors (93% right); fixed various typo errors.
 9.17 26/08/2015: Updated "messnoinfosets_?.txt" file to 0.165 version.
 9.16 15/08/2015: Fixed typos error in: "alltimesMESS.txt", "changelog.txt" and "sourcechanges.txt" (thanks to Stiletto).
 9.15 30/07/2015: Aligned files to 0.164 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until July 29, 2015 (r40040). Added other authors (91% right); fixed various typo errors.
 9.14 25/06/2015: Aligned files to 0.163 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until June 24, 2015 (r39030).
 9.13 22/06/2015: Added many authors (86% right); fixed various typo errors.
 9.12 21/06/2015: Updated the SVN until June 21, 2015 (r38709).
 9.11 02/06/2015: Aligned files to 0.162 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until May 27, 2015 (r38204). Added many authors (85% right).
 9.10 02/05/2015: Aligned files to 0.161 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until April 29, 2015 (r37458).
 9.09 26/04/2015: Added many authors (83% right).
 9.08 24/04/2015: Updated the SVN until April 24, 2015 (r37364).
 9.07 29/03/2015: Aligned files to 0.160 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until March 25, 2015 (r36625).
 9.06 11/03/2015: Updated the SVN until March 11, 2015 (r36375).
 9.05 26/02/2015: Aligned files to 0.159 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until February 25, 2015 (r35257).
 9.04 04/02/2015: Aligned files to 0.158 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt', 'supportedMEDIA.txt' and 'Index of Devices'. Updated the SVN until January 28, 2015 (r34635).
 9.03 22/01/2015: Updated the SVN until January 21, 2015 (r34529). Put the information on the machines added after 0.157 release.
 9.02 03/01/2015: Aligned files to 0.157 version (added all new machines with complete infos). Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS.txt', 'Drivers SVN...txt' and 'supportedMEDIA.txt'. Updated the SVN until December 31, 2014 (r34121). Also updated 'Index of Devices'.
 9.01 31/12/2014: Added 'softwarelists' complete xml.
 9.00 26/12/2014: Phase 8 completed! Presence of software lists for all sets (aligned to version 0.156 svn34060).
 8.15 24/12/2014: Completed the file 'changelog.txt' (0.1 to 0.156). Updated the SVN until December 24, 2014 (r34057).
 8.14 22/12/2014: Completed the file 'sourcechanges.txt' (0.1 to 0.156).
 8.13 20/12/2014: Updated the SVN until December 20, 2014 (r33931). Updated presence of software lists (92% right) and 72% of authors finded.
 8.12 28/11/2014: Aligned files to 0.156 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt' and 'supportedMEDIA.txt'. Updated the SVN until November 26, 2014 (r33555). Updated presence of software lists (64% right). Updated 'Index of Devices'.
 8.11 24/11/2014: Added 'supportedMEDIA' file. Renamed support file 'alltimesMESS_WIP.txt' to 'alltimesMESS.txt'.
 8.10 23/11/2014: Updated the SVN until November 21, 2014 (r33482). Corrected some minor errors.
 8.09 18/10/2014: Aligned files to 0.155 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until October 15, 2014 (r31761). Updated presence of software lists (64% right). Updated 'Index of Devices'.
 8.08 13/10/2014: Added many driver set from (msx.c). Updated the SVN until October 13, 2014 (r32705).
 8.07 12/09/2014: Updated the SVN until September 12, 2014 (r32078).
 8.06 25/07/2014: Aligned files to 0.154 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until July 23, 2014 (r31396). Updated presence of software lists (56% right). Updated 'Index of Devices'.
 8.05 22/06/2014: Updated the SVN until June 22, 2014 (r31075).
 8.04 10/06/2014: Updated the SVN until June 8, 2014 (r30892).
 8.03 29/05/2014: Updated presence of software lists (49% right) and updated the SVN until May 29, 2014 (r30708). Started the upgrade of the resources available (on my website) for each set (5% right).
 8.02 08/05/2014: Third birthday version! Updated the SVN until May 7, 2014 (r30318); also updated the 'Drivers SVN...txt' and 'version.ini' files.
 8.01 04/05/2014: Updated presence of software lists (42% right) and updated the SVN until May 3, 2014 (r30208).
 8.00 01/05/2014: Phase 7 completed! Compressed set size in kylobytes for all sets (aligned to version 0.153). Updated the SVN until April 22, 2014 (r29849).
 7.25 10/04/2014: Aligned files to 0.153 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until April  7, 2014 (r29405). Updated presence of software lists (39% right) and compressed set size in kylobytes (84% right). Updated 'Index of Devices'.
 7.24 29/03/2014: Added (at bottom of file) the 'Index of Devices' aligned to 0.152 version.
 7.23 27/03/2014: Updated compressed set size in kylobytes (72% right).
 7.22 22/03/2014: Updated the SVN until March 20, 2014 (r28767).
 7.21 11/03/2014: Updated the SVN until March 9, 2014 (r28347). Updated presence of software lists (28% right) and compressed set size in kylobytes (65% right).
 7.20 02/03/2014: Updated the SVN until March 1, 2014 (r28160).
 7.19 25/02/2014: Updated presence of software lists (19% right) and compressed set size in kylobytes (32% right). Updated the SVN until February 24, 2014 (r27963).
 7.18 22/02/2014: Updated the SVN until February 22, 2014 (r27906).
 7.17 12/02/2014: Start adding presence of software lists (right from '1292apvs' to 'byte') and reorder compressed set size in kylobytes (right from '1292apvs' to 'berlinp').
 7.16 31/01/2014: Updated the SVN until January 31, 2014 (r27365).
 7.15 29/12/2013: Aligned files to 0.152 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until December 24, 2013 (r26737).
 7.14 23/11/2013: Updated the SVN until November 23, 2013 (r26386).
 7.13 09/11/2013: Fixed authors of 0.151 adds (thanks to Nigel Barnes).
 7.12 08/11/2013: Aligned files to 0.151 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until November 5, 2013 (r26005).
 7.11 01/11/2013: Various fix in list of drivers and machines.
 7.10 21/10/2013: Updated the SVN until October 21, 2013 (r25769). Added info of 2 new drivers and 10 machines.
 7.09 19/09/2013: Aligned files to 0.150 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until September 17, 2013 (r25362).
 7.08 04/09/2013: Updated the SVN until September 4, 2013 (r25212).
 7.07 17/08/2013: Updated the SVN until August 17, 2013 (r24936).
 7.06 25/07/2013: Aligned files to 0.149u1 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until July 23, 2013 (r24475).
 7.05 09/07/2013: Updated the SVN until July 9, 2013 (r24145).
 7.04 12/06/2013: Aligned files to 0.149 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until June 11, 2013 (r23639).
 7.03 01/06/2013: Updated the SVN until June 1, 2013 (r23359).
 7.02 28/05/2013: Updated the SVN until May 28, 2013 (r23215).
 7.01 20/05/2013: Aligned files to 0.148u5 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until May 20, 2013 (r22988).
 7.00 18/05/2013: Fixed some items. Updated the SVN until May 18, 2013 (r22899).
 6.28 17/05/2013: Phase 6 completed! All available resources added (aligned to version 0.148).
 6.27 13/05/2013: Updated the SVN until May 13, 2013 (r22807). Added resources info; 1,934 sets checked, 75% right).
 6.26 01/05/2013: Aligned files to 0.148u4 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until April 30, 2013 (r22620).
 6.25 28/04/2013: Updated the SVN until April 28, 2013 (r22589).
 6.24 13/04/2013: Updated the SVN until April 13, 2013 (r22368).
 6.23 10/04/2013: Added info about three new sets added in 0.148u3.
 6.22 09/04/2013: Aligned files to 0.148u3 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until April 9, 2013 (r22292).
 6.21 06/04/2013: Updated the SVN until April 6, 2013 (r22246).
 6.20 25/03/2013: Added resources info; 1,500 sets checked, 66% right).
 6.19 19/03/2013: Aligned files to 0.148u2 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until March 19, 2013 (r21962).
 6.18 11/03/2013: Fixed 60 STATUS entries. Updated the SVN until March 9, 2013 (r21773). Added resources info; 1,266 sets checked, 57% right).
 6.17 04/03/2013: Updated the SVN until March 4, 2013 (r21572). Added resources info; 1,047 sets checked, 47% right).
 6.16 23/02/2013: Updated the SVN until February 23, 2013 (r21390). Added resources info; 876 sets checked, 40% right).
 6.15 19/02/2013: Updated the SVN until February 19, 2013 (r21180).
 6.14 13/02/2013: Aligned files to 0.148u1 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until February 11, 2013 (r20931).
 6.13 10/02/2013: Added resources info; 696 sets checked, 33% right).
 6.12 08/02/2013: Added info about one new set and updated the SVN until February 8, 2013 (r20836).
 6.11 01/02/2013: From today, the file will be released in two encodings (Windows and Unicode) to maintain compatibility with MESSUI and QMC2.
 6.10 31/01/2013: Added resources info; 627 sets checked, 29% right). Added info about two new set and updated the SVN until January 31, 2013 (r20626).
 6.09 29/01/2013: Updated the SVN until January 28, 2013 (r20579).
 6.08 23/01/2013: I finally started to add to messinfo (set to set) the resources available (here http://www.progettosnaps.net/), including: Artwork, Cabinet, Control Panel and Controllers, Flyer and Advertising, Manuals, Marquees and Logos and PCBs. For now we are only 5% (100 sets checked).
 6.07 21/01/2013: Updated the SVN until January 21, 2013 (r20390).
 6.06 11/01/2013: Aligned files to 0.148 stable version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until January 11, 2013 (r20196).
 6.05 28/12/2012: Updated the SVN until December 27, 2012 (r19871).
 6.04 18/12/2012: Aligned files to 0.147u4 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until December 17, 2012 (r19614).
 6.03 06/12/2012: Updated the SVN until December 6, 2012 (r19351).
 6.02 04/12/2012: Added to the compressed size of BIOSes not yet updated.
 6.01 19/11/2012: Aligned files to 0.147u3 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until November 19, 2012 (r19032).
 6.00 14/11/2012: Updated the SVN until November 14, 2012 (r18959). 
 5.39 12/11/2012: End of phase 5! Added 299 descriptions and all set are ok. Except for some sets of which I have found useful or verifiable, the list (262 sets) can be found here: http://www.progettosnaps.net/messinfo/messnoinfoset.txt. Who wants to help me complete info contact me!
 5.38 30/10/2012: Aligned files to 0.147u2 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until October 30, 2012 (r18777).
 5.37 28/10/2012: Added 253 (!) descriptions of MESS supported systems (1,416 right / 82% [+14%]). Fixed some errors accumulated in the last 5/6 versions.
 5.36 26/10/2012: Updated the SVN until October 26, 2012 (r18717).
 5.35 14/10/2012: All file converted to UTF-8 standard (reported by QMC2). Updated the SVN until October 11, 2012 (r18443).
 5.34 09/10/2012: Aligned files to 0.147u1 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until October 8, 2012 (r18354).
 5.33 26/09/2012: Added many descriptions of MESS supported systems (1,163 right / 68% - completed from 'A' to 'N').
 5.32 22/09/2012: Aligned files to 0.147 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until September 17, 2012 (r17960).
 5.31 17/09/2012: Correct the list of supported drivers.
 5.30 10/09/2012: Removed, in docs folder, the files: "quoting.txt", "softwarelist.txt"  and "todolist.txt".
 5.29 07/09/2012: Updated the SVN until September 10, 2012 (r17767).
 5.28 07/09/2012: Updated the SVN until September 3, 2012 (r17609).
 5.27 23/08/2012: Updated the SVN until August 27, 2012 (r17496). Deleted from messinfo pack the old SVN file, downloadable here: http://www.progettosnaps.net/messinfo/MESS_SVN_r1-15977_2012-08-20.zip.
 5.26 23/08/2012: Aligned files to 0.146u5 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until August 20, 2012 (r15977).
 5.25 02/08/2012: Aligned files to 0.146u4 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until July 30, 2012 (r15709).
 5.24 23/07/2012: Updated the SVN until July 23, 2012 (r15648). Added many descriptions of MESS supported systems (1,081 right, 63%).
 5.23 16/07/2012: Aligned files to 0.146u3 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until July 15, 2012 (r15605).
 5.22 11/07/2012: Eliminated all unnecessary spaces from the file: this made it sometimes difficult to read the information inside of the front-ends.
 5.21 02/07/2012: Aligned files to 0.146u2 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'. Updated the SVN until July 2, 2012 (r15527).
 5.20 26/06/2012: Updated the SVN until June 26, 2012 (r15504). Removed all references to bugs in Bugzilla (no longer active).
 5.19 12/06/2012: Aligned files to 0.146u1 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'.
 5.18 08/06/2012: Updated the SVN until June 8, 2012 (r15424). Added many descriptions of MESS supported systems (864 / 51% completed).
 5.17 01/06/2012: Updated the SVN until May 31, 2012 (r15363).
 5.16 24/05/2012: Aligned files to 0.146 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'.
 5.15 20/05/2012: Updated the SVN until May 19, 2012 (r15218).
 5.14 07/05/2012: Aligned files to 0.145u8 version. Updated the SVN until May 7, 2012 (r15112). Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' and 'Drivers SVN...txt'.
 5.13 24/04/2012: Aligned files to 0.145u7 version. Updated the SVN until April 24, 2012 (r15022). Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt', 'Drivers SVN...txt' and 
'version.ini'.
 5.12 20/04/2012: Updated the SVN until April 20, 2012 (r14977).
 5.11 17/04/2012: Updated the SVN until April 17, 2012 (r14946).
 5.10 13/04/2012: Updated the SVN until April 13, 2012 (r14904). Added 20 descriptions of MESS supported systems (mk85, mk90, mlf80, mm1m6, mm1m7, mpf1p, mprof3, mpt02, mpu1000, mpu2000, palmz22, pc6001a, pc6001mk2, pc6001sr, pc6601, pc7000, pc8001, pc8001mk2, pc8201a and pc8300).
 5.09 11/04/2012: Added many descriptions of MESS supported systems (apfimag, apfm1000, aplsbon, atmtb2, atom, avigo_de, avigo_es, avigo_fr, avigo_it, cpc300, cpc300e, cpc464, cpc6128f, cpc6128p, cpc6128s, cpc664, crvisio2, hb10p, hb201, hb201p, hb501p, hb75d, hb75p, hbf1, hmg2650, vg8020000, vg8020f, vg8235f, victor, victor9k, vidbrain, videopac, vii, vip, visicom, visor and vixen); we are still missing 1,245 (26% are completed).
 5.08 10/04/2012: Aligned files to 0.145u6 version. Updated the SVN until April 9, 2012 (r14886). Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' 'Drivers SVN...txt' and 'version.ini'.
 5.07 03/04/2012: Updated the SVN until April 3, 2012 (r14844). Added many descriptions of MESS supported systems (ibm5140, ibm5150, ibm5155, ibm5160, ibm5170, ibm5550, ibmpcjx, ibmpcjr, instruct, interact, intervsn, intmpt03, intv2, intvecs, intvkbd, intvsrs, inves, iq151, iskr1030m, iskr1031, ivelultr, ixl2000, jaguar, jaguarcd and jet).
 5.06 30/03/2012: Updated the SVN until March 30, 2012 (r14827).
 5.05 29/03/2012: Added to 'sourcechanges.txt' changes from 0.100 to 0.120.
 5.04 27/03/2012: Aligned files to 0.145u5 version. Updated the SVN until March 27, 2012 (r14814). Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' 'Drivers SVN...txt' and  'version.ini'.
 5.03 23/03/2012: Updated the SVN until March 23, 2012 (r14795).
 5.02 19/03/2012: Updated 'quotes.txt' and 'softwarelist.txt' files.
 5.01 18/03/2012: Updated 'sourcechanges.txt' file: right from 0.130 to 0.145u4.
 4.21 14/03/2012: Aligned files to 0.145u4 version. Updated this files: 'sourcechanges.txt', 'changelog.txt', 'alltimesMESS_WIP.txt' 'Drivers SVN...txt' and 'version.ini'.
 4.2216/03/2012: End of phase 4! All romset datas are present.
 4.20 13/03/2012: Updated the SVN until March 13, 2012 (r14655). Added some romset infos (bytes/# files/packed bytes), now 97% right, I'm almost done...
 4.19 06/03/2012: Updated the SVN until March 6, 2012 (r14699).
 4.18 03/03/2012: Added 30 romset descriptions (19% right).
 4.17 28/02/2012: Aligned files to 0.145u3 version. Updated the SVN until February 28, 2012 (r14652).
 4.16 26/02/2012: Added, in docs folder, the file 'sourcechanges.txt', this file stores all the changes made to the source of the MESS (info from official whatsnew.txt).
 4.15 24/02/2012: Added some romset infos (bytes/# files/packed bytes), now 91% right, from 'A' to 'S'. Changed the internal numbering of the file.
 4.14 21/02/2012: Aligned files to 0.145u1 version, add new systems and drivers, added some romset infos (bytes/# files). Updated the SVN until February 21, 2012 (r14563).
 4.13 14/02/2012: Added, in docs folder, the file 'Drivers SVN nnnnn (0.nnn) yyyymmdd.txt', bringing together in one file all the MESS drivers.
 4.12 12/02/2012: Added some romset infos (bytes/# files/packed bytes), now 84% right, from 'A' to 'R'.
 4.11 10/02/2012: Updated the SVN until February 10, 2012 (r14411). Fixed various 'cosmetic' errors.
 4.10 08/02/2012: Fixed type error ($infoc64n > $info=c64n). Add information about the sets that have all the art files (cabinets, flyers, icons and PCBs): it is only 10 sets (for now).
 4.09 07/02/2012: Aligned files to 0.145 version, add new systems and drivers, added some romset infos (bytes/# files). Updated the SVN until February 7, 2012 (r14374).
 4.08 31/01/2012: Aligned files to 0.144u7 version. Updated the SVN until January 31, 2012 (r14277).
 4.07 29/01/2012: Added some romset infos (bytes/# files/packed bytes), now 74% right.
 4.06 19/01/2012: Added some romset infos (bytes/# files/packed bytes), now 70% right. Updated the SVN until January 19, 2012 (r14089). Added to the web page the link to view the changelog.
 4.05 17/01/2012: Aligned files to 0.144u6 version.
 4.04 16/01/2012: Updated the SVN until January 16, 2012 (r14060). Added some romset infos (bytes/# files/packed bytes).
 4.03 11/01/2012: Added romset infos (bytes/# files/packed bytes) for 0.144u5.
 4.02 09/01/2012: Aligned files to 0.144u4 version. Updated the SVN until January 9, 2012 (r13954).
 4.01 07/01/2012: Fixed some type errors.
 4.00 05/01/2012: Updated the SVN until January 5, 2012 (r13829). Updated "version.ini" with set added in 0.144u3 and 0.144u4.
 3.50 02/01/2012: Added romset infos (bytes/# files/packed bytes) for 0.144u4 sets and fixed some positioning error alphabetical sets.
 3.49 26/12/2011: Aligned files to 0.144u4 version.
 3.48 21/12/2011: Updated the SVN until December 21, 2011 (r13647).
 3.47 20/12/2011: Added romset infos (bytes/# files/packed bytes) for 0.144u3 sets.
 3.46 16/12/2011: Aligned files to 0.144u3 version. Updated the SVN until December 16, 2011 (r13592). Added to "alltimesMESS_WIP.txt" 0.144u3 infos.
 3.45 15/12/2011: Updated the SVN until December 14, 2011 (r13574).
 3.44 12/12/2011: Finally complete the file "alltimesMESS_WIP.txt".
 3.43 09/12/2011: Added some romset infos (bytes/# files/packed bytes). Added to "alltimesMESS_WIP.txt" infos from 0.111 to 0.120.
 3.42 07/12/2011: Aligned files to 0.144u2 version. Updated the SVN until December 6, 2011 (r13486). Added to "alltimesMESS_WIP.txt" 0.144u2 infos.
 3.41a 03/12/2011: Added romset infos (bytes/# files/packed bytes) for 0.144u1 sets.
 3.41 29/11/2011: Aligned files to 0.144u1 version. Updated the SVN until November 28, 2011 (r13403). Added to "alltimesMESS_WIP.txt" 0.144 and 0.144u1 infos.
 3.40 21/11/2011: Added romset infos (bytes/# files/packed bytes) for 0.144 sets. Updated the SVN until November 21, 2011 (r13341).
 3.39 16/11/2011: Aligned files to 0.144 version. Updated the SVN until November 16, 2011 (r13277).
 3.38 13/11/2011: Renamed file "allMESS_WIP.txt" to "alltimesMESS_WIP.txt" and extended.
 3.37 11/11/2011: Updated the SVN until November 11, 2011 (r13215). 
 3.36 07/11/2011: Completed file "version.ini" (0.001 to 0.143u9); added many romset (bytes/# files/packed bytes) infos.
 3.35 04/11/2011: Updated the SVN until November 4, 2011 (r13169). 
 3.34 03/11/2011: Update file "sofwarelist.txt" (added juicebox.xml, updated gbcolor.xml, nes.xml and snes.xml). Added some romset infos (bytes/# files/packed bytes).
 3.33 31/10/2011: Added romset infos (bytes/# files/packed bytes) for 0.143u9 sets.
 3.32 28/10/2011: Aligned files to 0.143u9 version. Updated the SVN until October 28, 2011 (r13113).
 3.31 27/10/2011: Added a first version of the file "version.ini"; to put in "folders" of the MESS.
 3.30 26/10/2011: Added romset infos (bytes/# files/packed bytes) for 0.143u8 sets.
 3.29 24/10/2011: Aligned files to 0.143u8 version. Updated the SVN until October 25, 2011 (r13106).
 3.28 23/10/2011: Update file "sofwarelist.txt" (a2600.xml, gameboy.xml, gbcolor.xml, megadriv.xml, nes.xml, sg1000.xml, snes.xml and supracan.xml).
 3.27 20/10/2011: Added many romset (bytes/# files/packed bytes) infos; 55% right.
 3.26 17/10/2011: Extended file "allMESS_WIP.txt"; updated the SVN until October 17, 2011 (r13054).
 3.25 12/10/2011: Aligned files to 0.143u7 version. Updated the SVN until October 12, 2011 (r13031).
 3.24 11/10/2011: Update file "sofwarelist.txt" (coleco.xml, gba.xml, intv.xml, intvecs.xml, megadriv.xml, n64.xml, nes.xml, sg1000.xml, sms.xml and snes.xml).
 3.23 07/10/2011: Updated the SVN until October 7, 2011 (r13001). Added many romset (bytes/# files/packed bytes) infos; 49% right.
 3.22 03/10/2011: Updated the SVN until October 3, 2011 (r12974). Update file "sofwarelist.txt" (lisa.xlm and snes.xml).
 3.21 01/10/2011: Found and reported all sets that do not need roms (now 105); romsets no data, are now 860 (45% done).
 3.20 27/09/2011: Added many romset (bytes/# files/packed bytes) infos; 38% right.
 3.19 26/09/2011: Update file "sofwarelist.txt" (abc1600.xls, intv.xml and snes.xml); updated the SVN until September 26, 2011 (r12938).
 3.18 23/09/2011: Added romset (bytes/# files/packed bytes) infos (0.143u6 sets); extended file "allMESS_WIP.txt".
 3.17 22/09/2011: Aligned files to 0.143u6 version. Updated the SVN until September 22, 2011 (r12913).
 3.16 19/09/2011: Updated the SVN until September 19, 2011 (r12891). Added file "sofwarelist.txt" (in doc folder) which lists all the software currently run by MESS.
 3.15 14/09/2011: Extended file "allMESS_WIP.txt"; added the description of some systems.
 3.14 12/09/2011: Updated the SVN until September 12, 2011 (r12829). Added romset (bytes/# files/packed bytes) infos (0.143u5 sets). Start the job of writing the new file "MESSrenameSET.dat" and "MESSrenameSET.ini". Fixed minor bugs.
 3.13 09/09/2011: Extended file "allMESS_WIP.txt". Added the description of these systems: abc1600, abc80, abc800c, abc800m, abc802, gameboy, gbcolor, intv, samcoupe, sorcerer, snes, specpl3e, ts1000 and ts1500.
 3.12 07/09/2011: Updated the SVN until September 7, 2011 (r12808). Extended file "allMESS_WIP.txt". Aligned file to 0.143u5 version.
 3.11 05/09/2011: Updated the SVN until September 5, 2011 (r12789). Extended file "allMESS_WIP.txt". Added more information about content and size of romsets.
 3.10 02/09/2011: Updated the SVN until September 2, 2011 (r12766). Extended file "allMESS_WIP.txt".
 3.09 30/08/2011: Updated the SVN until August 29, 2011 (r12733). Extended and corrected the file "allMESS_WIP.txt".
 3.08 29/08/2011: Added information about content and size of the added or updated BIOS of MESS 0.143u4: have this information now to 19% of the total.
 3.07 26/08/2011: Aligned file to 0.143u4 version. Fixed some minor errors.
 3.06 24/08/2011: Added to 'docs' directory, the file "allMESS_WIP". That lists, version by version, all the additions and changes made; it is a pre-pre-release with only 7 MESS examined (the first 3 and last 4).
 3.05 23/08/2011: Updated the SVN until August 23, 2011 (r12700). Added information about content and size of the added or updated BIOS of MESS 0.143u3.
 3.04 18/08/2011: Updated the SVN until August 17, 2011 (r12654).
 3.02 12/08/2011: Added information about content and size of the added or updated BIOS of MESS 0.143u2.
 3.03 17/08/2011: Aligned file to 0.143u3 version.
 3.00 11/08/2011: Added the info taken from the SVN (from 1 to 11890): end of phase 2 (until July 5, 2011). Fixed some errors.
 2.00 28/07/2011: Aligned file to 0.143u2 version.
 1.12 20/07/2011: Added info about 0.135 version.
 1.11 19/07/2011: Added info about versions 0.132, 0.133 and 0.134.
 1.10 18/07/2011: Added info about 0.131 version.
 1.09 15/07/2011: Added info about versions 0.128, 0.129 and 0.130.
 1.08 13/07/2011: Added information about content and size of the added or updated BIOS of MESS 0.143u1.
 1.07 12/07/2011: Aligned file to 0.143u1 version; added info about versions 0.126.
 1.06 11/07/2011: Added info about versions 0.123, 0.124, 0.125. Added file "quoting.txt" to pack.
 1.05 08/07/2011: Added info about versions 0.115, 0.116, 0.117, 0.118, 0.119, 0.120, 0.121 and 0.122. The file is now at 90%.
 1.04 07/07/2011: Added info about 0.114 version; added info of romsets data (from "a5105" to "a800xl").
 1.03 06/07/2011: Added the info taken from the SVN (from 11891 to 12161 - July 5, 20111). Added info about versions 0.112 and 0.113.
 1.02 05/07/2011: Added information about content and size of the added or updated BIOS from MESS 0.142 to 0.143. Added info about versions 0.109, 0.110 and 0.111.
 1.01 04/07/2011: Added info about versions 0.104, 0.105, 0.106, 0.107 and 0.108.
 1.00 29/06/2011: Aligned file to 0.143 version. MESSINFO.DAT online!!!
 0.38 28/06/2011: Added info about versions 0.94, 0.95, 0.96, 0.97, 0.98, 0.99 and 0.100 (35 still missing it!).
 0.37 27/06/2011: Added info about 12 versions (0.82, 0.83, 0.84, 0.85, 0.86, 0.87, 0.88, 0.89, 0.90, 0.91, 0.92 and 0.93!). Added the info taken from the SVN (from 11298 to 11374).
 0.36 24/06/2011: Added info about version 0.132 (a big update with 198 systems added!).
 0.35 23/06/2011: Start adding info of romsets data (from "1292apvs" to "a500p").
 0.34 22/06/2011: Defined the package to be put online, with a zip to an internal self-extracting 7zip, containing: the messinfo.dat file and one folder doc (with history, todo-list and also the textual version of the SVN).
 0.33 21/06/2011: Added info about versions 0.79, 0.80 and 0.81. I thought I would add, in the bottom of each set, as well as the size and number of files that make up each romset, even the contents of the zip themselves the names of the roms, size and CRC32).
 0.32 20/06/2011: Aligned messinfo.dat to 0.142u6 version.
 0.31 17/06/2011: Added info about versions 0.71, 0.72, 0.73, 0.74, 0.77 and 0.78 (now 56% are right!).
 0.30 15/06/2011: Added info about versions 0.62.1, 0.63, 0.64, 0.65, 0.66, 0.67, 0.68, 0.69 and 0.70. Added the info taken from the SVN (from 11375 to 11684). Small correction to web page logo.
 0.29 14/06/2011: Added info about versions 0.61, 0.61.1, 0.61.2 and 0.62. The file is now at 47%! End check od drivers presence in messinfo.
 0.28 13/06/2011: Added info about version 0.137.
 0.27 12/06/2011: Added the info taken from the SVN (from 11684 to 11545). Checking for drivers in messinfo: completed from 'K' to 'O' (106 will remain to be verified).
 0.26 11/06/2011: Added info about versions 0.56 and 0.56.1. The file is now at 30%.
 0.25 10/06/2011: Translated into english the history file (which becomes the default language). Added info about 0.37b15 version. Added the info taken from the SVN (from 11685 to 11891).
 0.24 09/06/2011: Fixed some errors. Completely rewritten the page with a graphic style inspired by "mess.org".
 0.23 08/06/2011: Cleanup releases list (added unreleased versions). Added info regarding versions 0.37b12 and 0.37b13. Checking MESS drivers present in messinfo: completed from 'D' to 'J'.
 0.22 07/06/2011: Aligned messinfo.dat to 0.142u5 version; correct web page, new and final logo and moved the file on my site, there are still some links to fix. Checking for drivers in messinfo: completed from 'A' to 'C'.
 0.21 06/06/2011: Before writing this file dedicated to the historical progress of the project messinfo.dat (currently only in italian).
 0.20 05/06/2011: Added info about versions 0.37b10, 0.37b11 and 0138. First draft of the website to put online (the logo is provisional).
 0.15 02/06/2011: Fixed various errors. Started on the introduction of the BIOS Zip file sizes (from 32x to a130xe).
 0.14 31/05/2011: Added info about 0.142u4 version; added renamed sets from version 0.138 to 0.142u4.
 0.13 29/05/2011: Added info about 0.139 version. Completed the introductory summary.
 0.12 28/05/2011: Added info about versions 0.37b8 and 0.37b9. Update the data in the introductory summary.
 0.11 27/05/2011: Added info about versions 0.37b5, 0.37b6 and 0.37b7.
 0.10 26/05/2011: Added info about versions 0.37b3 and 0.37b4. Update the data in the introductory summary.
 0.09 22/05/2011: Added info about versions 0.36b13 and 0.36b14.
 0.08 25/05/2011: Added info about versions 0.36b15, 0.36b16, 0.36RC1 and 0.36RC2, corrected some mistakes. Update the data in the introductory summary.
 0.07 22/05/2011: Added info about versions 0.36b13 and 0.36b14.
 0.06 20/05/2011: Added info about versions 0.36b11, 0.36b12 and 0.140. Fixed various errors.
 0.05 19/05/2011: Added info about versions 0.36b6, 0.36b7, 0.36b8 and 0.141. Update the data in the introductory summary.
 0.04 16/05/2011: The file (only for backup and debug) is online at mameworld.info.
 0.03 14/05/2011: Modified again the file structure (standardized to mameinfo.dat) added informations of the last issued MESS (from 0.142 to 0.142u3).
 0.02 12/05/2011: Several corrections to the structure and syntax of the file (thanks to Fabio Priuli); added informations of the first three releases MESS (info on source/whatsnew).
 0.01 11/05/2011: First version of the file (using the 'print to file' a report generated from a table of Microsoft Access) using the systems in MESS 0.142.
 0.00 08/05/2011: He was born the idea for this new MESS project, drawing inspiration from mameinfo.dat of MASH.


© 2011/2019 AntoPISA